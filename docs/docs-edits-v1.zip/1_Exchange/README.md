# Nauticus Exchange Help Center



### FAQ and other Helpful Information

