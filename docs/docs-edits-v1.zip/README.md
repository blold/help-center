---
home: true 
heroImage: https://nauticus.exchange/help/images/Logo-1.png
actionText: Nauticus Exchange Help Center →
actionLink: /1_Exchange/
features:
- title: Markdown Editing 
  details: Netlify's CMS provides a flexible Markdown Editor 
- title: Asset Management 
  details: Easily upload images to your repo with an uploader 
- title: Powerful Deployments
  details: Leverage the power of netlify and VuePress to deploy statically 
footer: MIT Licensed | Copyright © 2018-present Andre Liem (www.vuejsradar.com) 
title: FRONT PAGE
---

